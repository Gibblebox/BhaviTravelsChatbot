import aiohttp
import asyncio
import json
import requests
from flightsearch.vo.AkasaResponseVO import APIResponse as akasaRes
import pydantic
from flightsearch.flightsearchutil.FlightSearchUtil import FlightSearchUtil


def lambda_handler(event, context):
    # TODO implement
    # Fetching JSON request data
    if 'body' in event:
        # Assuming request is passed as JSON string
        request_data = event['body']
        print('### Here is the request data')
        print(request_data)
    else:
        request_data = event  # If request is not wrapped in 'body'
    print('%%%%%%Here are the events ')
    print(event)

    # asyncio.run(main(request_data,authorization_token))
    token = getToken()
    consolidated_response = asyncio.run(main(request_data, token))

    #####
    #with open('flight_search/json/AkasaResponseSample.json', 'r') as akasa_response:
     #   json_data = json.load(akasa_response)
    # print(json_data)


    try:
        akasaFlightSearchAPIRes = akasaRes.parse_obj(consolidated_response)
        print(akasaFlightSearchAPIRes.data.results[0].trips[0].date)
        print('$$$$$$$$')
        scaleXDataRes = FlightSearchUtil.mapAkasaResToScaleXDataStructure(akasaFlightSearchAPIRes)
        print(scaleXDataRes.json())

    except pydantic.ValidationError as e:
        print(e.json())

    ####

    return consolidated_response


def getToken():
    tokenResponse = requests.post('https://t-extprt-reyalrb.qp.akasaair.com/api/nsk/v2/token',
                                  json={
                                      "credentials": {
                                          "username": "QPAMD6052C_01",
                                          "password": "Mar@2024",
                                          "domain": "EXT"
                                      }
                                  }
                                  )
    print('Here is the token')
    token = tokenResponse.json().get('data').get('token')
    print(token)
    return 'Bearer '+token


async def post_request(session, url, headers, data):
    async with session.post(url, headers=headers, data=json.dumps(data)) as response:
        return await response.json()


async def fetch_all(request_data, authorization_token):
    print('@@@@@@@@final token' + authorization_token)
    async with aiohttp.ClientSession() as session:
        tasks = [

            post_request(session,
                         'https://t-extprt-reyalrb.qp.akasaair.com/api/nsk/v4/availability/search/simple',
                         headers={"Authorization": authorization_token,
                                  "Content-Type": "application/json"},
                         data=request_data
                         )

        ]
        responses = await asyncio.gather(*tasks)
        return responses


async def main(request_data, authorization_token):
    responses = await fetch_all(request_data, authorization_token)
    # Consolidate the responses. Adjust structure as needed.
    consolidated_response = responses[0]
       
   # {
    #    'api1': responses[0],
    #}
    return consolidated_response



