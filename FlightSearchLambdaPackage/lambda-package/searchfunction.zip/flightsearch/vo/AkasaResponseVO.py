from typing import List, Optional, Dict
from pydantic import BaseModel

class Designator(BaseModel):
    destination: str
    origin: str
    arrival: str
    departure: str

class Identifier(BaseModel):
    identifier: str
    carrierCode: str
    opSuffix: Optional[str] = None

class LegInfo(BaseModel):
    departureTimeUtc: str
    arrivalTimeUtc: str
    adjustedCapacity: int
    arrivalTerminal: str
    arrivalTimeVariant: int
    backMoveDays: int
    capacity: int
    changeOfDirection: bool
    codeShareIndicator: int
    departureTerminal: Optional[str] = None
    departureTimeVariant: int
    equipmentType: str
    equipmentTypeSuffix: Optional[str] = None
    eTicket: bool
    irop: bool
    lid: int
    marketingCode: Optional[str] = None
    marketingOverride: bool
    operatedByText: Optional[str] = None
    operatingCarrier: Optional[str] = None
    operatingFlightNumber: Optional[str] = None
    operatingOpSuffix: Optional[str] = None
    outMoveDays: int
    arrivalTime: str
    departureTime: str
    prbcCode: str
    scheduleServiceType: str
    sold: int
    status: int
    subjectToGovtApproval: bool

class Leg(BaseModel):
    legKey: str
    operationsInfo: Optional[Dict] = None
    designator: Designator
    legInfo: LegInfo
    nests: List[Dict] = []
    ssrs: List[Dict] = []
    seatmapReference: str
    flightReference: str

class Segment(BaseModel):
    isChangeOfGauge: bool
    isBlocked: bool
    isHosted: bool
    designator: Designator
    isSeatmapViewable: bool
    segmentKey: str
    identifier: Identifier
    cabinOfService: Optional[str] = None
    externalIdentifier: Optional[str] = None
    international: bool
    segmentType: int
    legs: List[Leg]

class FareDetail(BaseModel):
    availableCount: int
    status: int
    reference: str
    serviceBundleSetCode: Optional[str] = None
    bundleReferences: Optional[str] = None
    ssrReferences: Optional[str] = None

class Fare(BaseModel):
    fareAvailabilityKey: str
    details: List[FareDetail]
    isSumOfSector: bool

class Journey(BaseModel):
    flightType: int
    stops: int
    designator: Designator
    journeyKey: str
    segments: List[Segment]
    fares: List[Fare]
    notForGeneralUser: bool

class Trip(BaseModel):
    multipleOriginStations: bool
    multipleDestinationStations: bool
    date: str
    journeysAvailableByMarket: Dict[str, List[Journey]]

class Result(BaseModel):
    trips: List[Trip]
    #faresAvailable: Dict[str, Dict]
    #currencyCode: str
    #includeTaxesAndFees: bool
    #bundleOffers: Optional[Dict] = None

class Data(BaseModel):
    results: List[Result]
    faresAvailable: Dict[str, Dict]

class APIResponse(BaseModel):
    data: Data
